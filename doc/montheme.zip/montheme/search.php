<?php
// Template pour les pages de résultat de recherche