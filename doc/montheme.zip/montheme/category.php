<?php
// Template pour les catégories