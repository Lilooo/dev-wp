<div class="wrap">
  <h1>Bonjour</h1>
  <p>Ceci est mon plugin</p>
</div>