<?php
/*
Plugin Name: Mon plugin TOTO
Plugin URI: http://monplugintoto.com
Description: Un plugin pour apprendre à faire des plugins
Author: Moi
Author URI: http://moimoi.com
Version: 0.1
*/

//Inclure un fichier de fonctions
require_once plugin_dir_path(__FILE__) . 'includes/toto-functions.php';



